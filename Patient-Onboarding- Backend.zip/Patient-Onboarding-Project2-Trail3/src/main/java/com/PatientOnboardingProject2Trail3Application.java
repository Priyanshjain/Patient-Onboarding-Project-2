package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientOnboardingProject2Trail3Application {

	public static void main(String[] args) {
		SpringApplication.run(PatientOnboardingProject2Trail3Application.class, args);
	}

}
