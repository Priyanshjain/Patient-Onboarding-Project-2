import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-time-patient',
  templateUrl: './doctor-time-patient.component.html',
  styleUrls: ['./doctor-time-patient.component.css']
})
export class DoctorTimePatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
