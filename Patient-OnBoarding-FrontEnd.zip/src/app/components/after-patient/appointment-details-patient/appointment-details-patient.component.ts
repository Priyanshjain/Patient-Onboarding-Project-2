import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-details-patient',
  templateUrl: './appointment-details-patient.component.html',
  styleUrls: ['./appointment-details-patient.component.css']
})
export class AppointmentDetailsPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
