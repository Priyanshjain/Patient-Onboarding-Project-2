import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-form-patient',
  templateUrl: './appointment-form-patient.component.html',
  styleUrls: ['./appointment-form-patient.component.css']
})
export class AppointmentFormPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
