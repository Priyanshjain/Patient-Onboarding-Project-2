import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-details-patient',
  templateUrl: './self-details-patient.component.html',
  styleUrls: ['./self-details-patient.component.css']
})
export class SelfDetailsPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
