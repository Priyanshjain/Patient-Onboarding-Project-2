import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-details-rece',
  templateUrl: './bill-details-rece.component.html',
  styleUrls: ['./bill-details-rece.component.css']
})
export class BillDetailsReceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
