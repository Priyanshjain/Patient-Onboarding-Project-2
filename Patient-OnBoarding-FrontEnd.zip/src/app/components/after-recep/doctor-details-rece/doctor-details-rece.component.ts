import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-details-rece',
  templateUrl: './doctor-details-rece.component.html',
  styleUrls: ['./doctor-details-rece.component.css']
})
export class DoctorDetailsReceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
