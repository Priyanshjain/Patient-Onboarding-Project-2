import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-details-rece',
  templateUrl: './patient-details-rece.component.html',
  styleUrls: ['./patient-details-rece.component.css']
})
export class PatientDetailsReceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
