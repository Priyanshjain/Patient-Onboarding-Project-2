import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-patient-rece',
  templateUrl: './add-patient-rece.component.html',
  styleUrls: ['./add-patient-rece.component.css']
})
export class AddPatientReceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
