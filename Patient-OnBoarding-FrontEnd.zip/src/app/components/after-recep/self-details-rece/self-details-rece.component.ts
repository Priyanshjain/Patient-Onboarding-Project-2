import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-details-rece',
  templateUrl: './self-details-rece.component.html',
  styleUrls: ['./self-details-rece.component.css']
})
export class SelfDetailsReceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
