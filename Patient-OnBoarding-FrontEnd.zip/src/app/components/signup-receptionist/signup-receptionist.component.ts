import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-receptionist',
  templateUrl: './signup-receptionist.component.html',
  styleUrls: ['./signup-receptionist.component.css']
})
export class SignupReceptionistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
