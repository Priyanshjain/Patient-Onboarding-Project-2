import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-details-doctor',
  templateUrl: './appointment-details-doctor.component.html',
  styleUrls: ['./appointment-details-doctor.component.css']
})
export class AppointmentDetailsDoctorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
