import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-details-doctor',
  templateUrl: './self-details-doctor.component.html',
  styleUrls: ['./self-details-doctor.component.css']
})
export class SelfDetailsDoctorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
