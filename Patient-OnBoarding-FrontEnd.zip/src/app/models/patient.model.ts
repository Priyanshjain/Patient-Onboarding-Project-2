export class Patient {
}
