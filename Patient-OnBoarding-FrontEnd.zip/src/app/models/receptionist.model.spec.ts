import { Receptionist } from './receptionist.model';

describe('Receptionist', () => {
  it('should create an instance', () => {
    expect(new Receptionist()).toBeTruthy();
  });
});
