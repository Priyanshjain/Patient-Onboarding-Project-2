export class Doctor {

    doctorId? : number;
    doctorName? : String;
    phoneNumber? : String;
    email? : String;
    password? : String;
    specialisation? : String;
    

}
