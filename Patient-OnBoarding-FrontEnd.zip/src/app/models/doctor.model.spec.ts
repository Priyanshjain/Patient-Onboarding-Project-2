import { Doctor } from './doctor.model';

describe('Doctor', () => {
  it('should create an instance', () => {
    expect(new Doctor()).toBeTruthy();
  });
});
