export class Receptionist {
}
